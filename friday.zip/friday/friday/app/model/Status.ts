export interface Status {
    queryStatus: boolean
}