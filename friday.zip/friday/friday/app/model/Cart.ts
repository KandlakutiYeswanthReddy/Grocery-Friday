export class Cart {
    pid: number
    uid: number
    cid: number
    qty: number
    total: number
    status: string
    fk:number
    pfk:number
    
    constructor() {
        this.pid = 0
        this.cid = 0
        this.qty=0
        this.total=0
        this.status=''
        this.fk=0,
        this.pfk=0
       
    }
}
