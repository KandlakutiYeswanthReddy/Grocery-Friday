import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Category } from './model/Category';
import { Product } from './model/Product';
import { User } from './model/User';
import { environment } from '../environments/environment';
import { Cart } from './model/Cart';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class CartService {
  currentUser: User
  carts:Cart[]
  constructor(public http: HttpClient) { 

  }
  addToCart(cart: Cart)
  {
    return this.http.post('http://172.18.218.134:' + environment.port + '/grocery/cart/save', cart, httpOptions)
  }
}
