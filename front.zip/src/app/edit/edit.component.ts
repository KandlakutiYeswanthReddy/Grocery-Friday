import { Component, OnInit,Input } from '@angular/core';
import { ProductService } from './../product.service';
import { Product } from './../model/Product';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  @Input()
  editedProduct: Product

  @Input()
  index: number
  successFlag: boolean
  constructor(public prodService: ProductService) { }

  ngOnInit() {
  }

  editProduct(editForm) {

    var obj: Product = new Product()

    obj.pid = this.editedProduct.pid
    obj.cid=this.editedProduct.cid
    obj.pname = editForm.form.value.pname
    obj.pqty = editForm.form.value.pqty
    obj.price = editForm.form.value.price
    obj.unit = editForm.form.value.unit


    this.prodService.editProduct(obj)
      .subscribe((data: Product) => {
        console.log(data)
        this.prodService.products[this.index].pid = obj.pid
        this.prodService.products[this.index].cid = obj.cid
        this.prodService.products[this.index].pname = obj.pname
        this.prodService.products[this.index].pqty= obj.pqty
        this.prodService.products[this.index].price = obj.price
        this.prodService.products[this.index].unit = obj.unit
        editForm.form.markAsPristine()
        this.successFlag = true
      })
  }
}
