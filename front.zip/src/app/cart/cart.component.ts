import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationEnd } from '@angular/router';
import { Cart } from './../model/Cart';
import { Order } from './../model/Order';
import { Status } from './../model/Status';
import { AuthenticateService } from '../authenticate.service';
import { CartService } from './../cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart:Cart
  carts:Cart[]
  order:Order
  no:number
  progressFlag: boolean
  constructor( public cartService: CartService,public authService: AuthenticateService,public router: Router) {
this.order=new Order()
this.no=0
  this.cart=new Cart()
  this.carts=[]
  this.cartService.orders=[]
   this.carts=this.cartService.carts 
   }



   deleteCartItem(cartid, index) {
    this.cartService.deleteCartItem(cartid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.carts.splice(index, 1)
      })
  }

  ngOnInit() {
  }

  placeOrder(id)
  {
 this.order.ufk=this.authService.currentUser.id
 this.order.oid=0
 for (let i = 0; i < this.cartService.carts.length; i++)
    {
      this.no=this.cartService.carts[i].total + this.no
    }
this.order.total=this.no
console.log(this.order.total)
console.log(this.order.ufk)


this.cartService.placeOrder(this.order)
      .subscribe((res: Order) => {

        if (res !== null) {
          
          
          this.router.navigateByUrl('/cart')
        }
        else {
          
        }
      }, err => {
        console.log(err)
       

      })

  }
}
