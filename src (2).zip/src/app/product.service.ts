import { Injectable } from '@angular/core';
import { Product } from './model/Product';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productStatus: boolean
  adminStatus: boolean
  public products: Product[]
  public productcat: Product[]

  public constructor(public http: HttpClient) {
    this.productStatus = false
    this.products = []
    this.productcat = []

   }
   addProduct(product: Product) {
    return this.http.post('http://172.18.218.134:'+environment.port+'/grocery/products/save', product, httpOptions)
  }
  getProduct()
  {
    return this.http.get('http://172.18.218.134:'+environment.port+'/grocery/products/all', httpOptions)
  }

  deleteProduct(pid:number) {
    return this.http.delete('http://172.18.218.134:'+environment.port+'/grocery/products/delete/' + pid, httpOptions)
  }
  editProduct(product: Product) {
    return this.http.put('http://172.18.218.134:'+environment.port+'/grocery/products/edit', product, httpOptions)
  }
  productbyCategory(cid:number)
  {
    return this.http.get('http://172.18.218.134:'+environment.port+'/grocery/products/all/'+cid, httpOptions)
  }
}
