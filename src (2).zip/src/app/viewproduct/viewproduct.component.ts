import { Component, OnInit } from '@angular/core';
import { ProductService } from './../product.service';
import { CartService } from './../cart.service';
import { Product } from './../model/Product';
import { Router, Event, NavigationEnd } from '@angular/router';
import { Cart } from './../model/Cart';
import { AuthenticateService } from '../authenticate.service';
@Component({
  selector: 'app-viewproduct',
  templateUrl: './viewproduct.component.html',
  styleUrls: ['./viewproduct.component.css']
})

export class ViewproductComponent implements OnInit {
  successFlag: boolean
  errorFlag: boolean
  progressFlag: boolean
  myColor: string
  cart: Cart
  no: number
  constructor(public prodService: ProductService, public cartService: CartService, public authService: AuthenticateService, public router: Router) {

    this.myColor = 'text-info'
    this.cart = new Cart()
  }

  increase(index: number) {
    this.no = this.prodService.productcat[index].uqty++
  }

  decrease(index: number) {
    if (this.prodService.productcat[index].uqty > 0) {
      this.no = this.prodService.productcat[index].uqty--
    }
  }


  ngOnInit() {
  }

  addToCart(index: number) {


    if (this.prodService.productcat[index].uqty > 0) {
      this.cart.cid = 0
      this.cart.pfk = this.prodService.productcat[index].pid
      this.cart.uqty = this.prodService.productcat[index].uqty
      this.cart.total = (this.prodService.productcat[index].price * this.prodService.productcat[index].uqty)
      this.cart.status = false
      this.cart.fk = this.authService.currentUser.id
    }


    this.cartService.addToCart(this.cart)
      .subscribe((res: Cart) => {

        if (res !== null) {
          this.successFlag = true
          this.prodService.productcat[index].uqty = 0
           
          this.router.navigateByUrl('/Viewproduct')
        }
        else {
          this.errorFlag = true

        }
      }, err => {
        console.log(err)
        this.errorFlag = true

      })
     
      if(this.successFlag)
      {
        window.alert("your item addeded to the cart !!!")
      }
  }
  

}
