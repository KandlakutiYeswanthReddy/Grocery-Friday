import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Order } from '../model/Order';
import { AuthenticateService } from '../authenticate.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
total:number
order:Order[]
  constructor(public cartService:CartService,public authService:AuthenticateService) { 
    
  }

  ngOnInit() {
  }

}
